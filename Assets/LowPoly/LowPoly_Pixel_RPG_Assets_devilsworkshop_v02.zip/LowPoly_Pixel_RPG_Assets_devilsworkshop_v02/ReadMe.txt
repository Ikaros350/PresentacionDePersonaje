 +-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+
 |D|e|v|i|l|'|s| |W|o|r|k|.|s|h|o|p|
 +-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


Please visit the link below for the latest license information 

https://devilsworkshop.itch.io/low-poly-3d-and-pixel-2d-rpg-game-assets


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



Credits 
Ajay Karat | Devil's Work.shop
http://devilswork.shop/ 


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


If you like this Game Asset Pack, please consider taking a moment to rate/review it.
Your continued support helps The Devil's Work.shop bring new improvements to the pack!


::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Support - 

Devil's Work.shop
help@devilswork.shop
http://devilswork.shop/
http://twitter.com/devilswork_shop 
